# Mass SMTP CHECKER

MASS SMTP CHECKER			   

Format list  IP:USER:PASS

usage : 
python cok.py 
run with python 3
